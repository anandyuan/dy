import json
from logging import error
from urllib import response
from django.http import HttpResponse
from django.http.response import  HttpResponseRedirect, JsonResponse
import requests

# 将客户端的某些网络请求原封不动转发到另一服务器
def handler(request):
    if request.method == "POST":

        url_val = request.POST.get("url")
        headers_val = request.POST.get("headers")

        headers = json.loads(headers_val)
        # print(headers["Cookie"])
        print(url_val[:50])

        h =  {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "accept-encoding": "gzip, deflate",
    "accept-language": "zh-CN,zh;q=0.9",
    "cache-control": "no-cache",
    "cookie": "douyin.com; s_v_web_id=verify_l77pb8ds_WGI9uNtm_TuqN_4D7M_8Aie_cC0iSQGjuBGA; ttcid=0d98dc486f1f49e0836c835757bee61d36; tt_scid=LIT.xhWdFZLuV9OedN0loXMHc4VSj1tp40oDHZPcXB3M1tQU8XqVIg3tPZhI7mEQb1a4; msToken=8CXvs6Sj-IsPmdO0102MQhkKQq2zQdZBF3pb3ogoU5ZMklDJ-Uv91yNdktxnb4V4jUtvLu08F_12t-xKTDeOlvPZSsMmnUCB9LPM-n1-HmqTRnE7gvThBKCA4xq-lw==",
    "pragma": "max-age=0",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36",
}

        res = requests.get(url=url_val,headers=h)

        try:
            # print(res.json())
            return JsonResponse(res.json(),safe=False)
        except Exception as e:
            error(e)
            return JsonResponse({})    
        # response = HttpResponse(res.json())
        # response.headers["Content-Type"] = "application/json"

        












        # # headers = dict(request.headers)
        # url = request.POST.get("url","nourl11")
        # print(request.POST.get("headers"))
       

        # if headers.get("Content-Length"):
        
        #     del headers["Content-Length"]
        #     print("del Content-Length")
        
        # headers['Referer'] = "https://www.douyin.com/"

        # print(url)
        # res = requests.get(url=url,headers=headers)

        # # print("ok")
        # print(res.json())

    # return JsonResponse({},safe=False)
    # return JsonResponse(res.json(),safe=False)

        # new 
        # 获取url
        # """url = "https://www.douyin.com" + request.get_full_path()
        # headers = dict(request.headers)
        # response = requests.get(url=url,headers=headers)
        # # 尝试直接使用dy返回的json
        # if response.headers.get("Connection") :
        #     del response.headers["Connection"]
        # # 设置响应类型
        # response.headers["Content-Type"] = "application/json"
        # return JsonResponse(response.json(),safe=False)"""

        



        # 请求头先不做处理
        # headers = dict(request.headers)
        # url =" https://" + request.get_host() + request.get_full_path()
        # res = requests.get(url=url,headers=headers )
    
        # response = HttpResponse(res.json())
        # response.headers = dict(res.headers)
        # # 处理响应头
        # if response.headers["Connection"] :
        #     del response.headers["Connection"]
        # # 设置响应类型
        # response.headers["Content-Type"] = "application/json"
        
        # return response


        

