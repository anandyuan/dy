# http://127.0.0.1:8080/aweme/v1/web/hot/search/list/?device_platform=webapp&aid=6383&channel=channel_pc_web&detail_list=1&source=6&version_code=170400&version_name=17.4.0&cookie_enabled=true&screen_width=1536&screen_height=864&browser_language=zh-CN&browser_platform=Win32&browser_name=Chrome&browser_version=104.0.0.0&browser_online=true&engine_name=Blink&engine_version=104.0.0.0&os_name=Windows&os_version=10&cpu_core_num=8&device_memory=8&platform=PC&downlink=10&effective_type=4g&round_trip_time=100&webid=7108568165185701410&msToken=PZjOcGLGVPGHLuHN8Q6PSOucM4AzOQHakQKyXw679zvH5dp4IGnQJ_pCaRxt4qNRpKtfQpO4ErnsA4ibi3KUdecCzrbKUMo14TcrD0Zm64L2n3qUauj7&X-Bogus=DFSzsnVY/qvANcU9SB-JTM9WX7n5

import requests
from django.http import JsonResponse, HttpResponse

headers = {
                "Accept": "application/json, text/plain, */*",
                "Accept-Encoding": "gzip, deflate, br",
                "Accept-Language": "zh-CN,zh;q=0.9",
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "Host":"douyin.com",
                "Referer":"https://www.douyin.com/",
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36",
                }

# aweme/v1/web/tab/feed/
def feed(request):
    if request.method == "GET":
        url = "https://www.douyin.com/aweme/v1/web/tab/feed/"
        params = {
            "device_platform": "webapp",
            "aid": "6383",
            "channel": "channel_pc_web",
            "tag_id": request.GET.get("tag_id"),
            "share_aweme_id": request.GET.get("share_aweme_id"),
            "count": request.GET.get("count"),
            "refresh_index": request.GET.get("refresh_index"),
            "video_type_select": request.GET.get("video_type_select"),
            "globalwid": request.GET.get("globalwid"),
            "ug_source": request.GET.get("ug_source"),
            "creative_id": request.GET.get("creative_id"),
            "version_code": "170400",
            "version_name": "17.4.0",
            "cookie_enabled": "true",
            "screen_width": "1920",
            "screen_height": "1080",
            "browser_language": "zh-CN",
            "browser_platform": "MacIntel",
            "browser_name": "Chrome",
            "browser_version": "104.0.0.0",
            "browser_online": "true",
            "engine_name": "Blink",
            "engine_version": "104.0.0.0",
            "os_name": "MacOS",
            "os_version": "10.15.7",
            "cpu_core_num": "4",
            "device_memory": "8",
            "platform": "PC",
            "downlink": request.GET.get("downlink"),
            "effective_type": "4g",
            "round_trip_time": request.GET.get("round_trip_time"),
            "aweme_pc_rec_raw_data": request.GET.get("aweme_pc_rec_raw_data"),
            "webid": request.GET.get("webid"),
            "mstoken": request.GET.get("msToken"),
            "x_bogus": request.GET.get("X-Bogus"),
            "_signature": request.GET.get("_signature"),
        }

        cookie = request.META.get("HTTP_COOKIE")
        headers_new = dict(headers)
        headers_new["Cookie"] = cookie
        
        res = requests.get(url=url,params=params,headers=headers)

        return JsonResponse(res.json())


# /aweme/v1/web/hot/search/list/
def search_list(request):
        if request.method == "GET":
            url = "https://www.douyin.com/aweme/v1/web/hot/search/list/"
            params = {
                "device_platform": "webapp",
                "aid": "6383",
                "channel": "channel_pc_web",
                "detail_list": request.GET.get("detail_list"),
                "source": request.GET.get("source"),
                "version_code": "170400",
                "version_name": "17.4.0",
                "cookie_enabled": "true",
                "screen_width": "1920",
                "screen_height": "1080",
                "browser_language": "zh-CN",
                "browser_platform": "MacIntel",
                "browser_name": "Chrome",
                "browser_version": "104.0.0.0",
                "browser_online": "true",
                "engine_name": "Blink",
                "engine_version": "104.0.0.0",
                "os_name": "MacOS",
                "os_version": "10.15.7",
                "cpu_core_num": "4",
                "device_memory": "8",
                "platform": "PC",
                "downlink": request.GET.get("downlink"),
                "effective_type": "4g",
                "round_trip_time": request.GET.get("round_trip_time"),
                "webid": request.GET.get("webid"),
                "mstoken": request.GET.get("msToken"),
                "x_bogus": request.GET.get("X-Bogus"),
                "_signature": request.GET.get("_signature"),
            }

            cookie = request.META.get("HTTP_COOKIE")
            headers_new = dict(headers)
            headers_new["Cookie"] = cookie

            res = requests.get(url=url,params=params,headers=headers_new)

        return JsonResponse(res.json())

# aweme/v1/web/notice/count/
def notice(request):
    if request.method == "GET":
            url = "https://www.douyin.com/aweme/v1/web/notice/count/"
            params = {
                "device_platform": "webapp",
                "aid": "6383",
                "channel": "channel_pc_web",
                "is_new_notice":request.GET.get("is_new_notice"),
                "detail_list": request.GET.get("detail_list"),
                "source": request.GET.get("source"),
                "version_code": "170400",
                "version_name": "17.4.0",
                "cookie_enabled": "true",
                "screen_width": "1920",
                "screen_height": "1080",
                "browser_language": "zh-CN",
                "browser_platform": "MacIntel",
                "browser_name": "Chrome",
                "browser_version": "104.0.0.0",
                "browser_online": "true",
                "engine_name": "Blink",
                "engine_version": "104.0.0.0",
                "os_name": "MacOS",
                "os_version": "10.15.7",
                "cpu_core_num": "4",
                "device_memory": "8",
                "platform": "PC",
                "downlink": request.GET.get("downlink"),
                "effective_type": "4g",
                "round_trip_time": request.GET.get("round_trip_time"),
                "webid": request.GET.get("webid"),
                "mstoken": request.GET.get("msToken"),
                "x_bogus": request.GET.get("X-Bogus"),
                "_signature": request.GET.get("_signature"),
            }

            cookie = request.META.get("HTTP_COOKIE")
            headers_new = dict(headers)
            headers_new["Cookie"] = cookie

            res = requests.get(url=url,params=params,headers=headers_new)

    return JsonResponse(res.json())

# aweme/v1/web/emoji/list
def emoji(request):
    if request.method == "GET":
            url = "https://www.douyin.com/aweme/v1/web/emoji/list"
            params = {
                "device_platform": "webapp",
                "aid": "6383",
                "channel": "channel_pc_web",
                "publish_video_strategy_type":request.GET.get("publish_video_strategy_type"),
                "version_code": "170400",
                "version_name": "17.4.0",
                "cookie_enabled": "true",
                "screen_width": "1920",
                "screen_height": "1080",
                "browser_language": "zh-CN",
                "browser_platform": "MacIntel",
                "browser_name": "Chrome",
                "browser_version": "104.0.0.0",
                "browser_online": "true",
                "engine_name": "Blink",
                "engine_version": "104.0.0.0",
                "os_name": "MacOS",
                "os_version": "10.15.7",
                "cpu_core_num": "4",
                "device_memory": "8",
                "platform": "PC",
                "downlink": request.GET.get("downlink"),
                "effective_type": "4g",
                "round_trip_time": request.GET.get("round_trip_time"),
                "webid": request.GET.get("webid"),
                "mstoken": request.GET.get("msToken"),
                "x_bogus": request.GET.get("X-Bogus"),
                "_signature": request.GET.get("_signature"),
            }

            cookie = request.META.get("HTTP_COOKIE")
            headers_new = dict(headers)
            headers_new["Cookie"] = cookie

            res = requests.get(url=url,params=params,headers=headers_new)

    return JsonResponse(res.json())

# aweme/v1/web/api/suggest_words/
# def words(request):
#     pass

