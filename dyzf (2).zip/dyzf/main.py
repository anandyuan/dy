# encoding=’utf-8’
import requests

url = "https://www.douyin.com/aweme/v1/web/api/suggest_words/?device_platform=webapp&aid=6383&channel=channel_pc_web&business_id=30082&version_code=170400&version_name=17.4.0&cookie_enabled=true&screen_width=1536&screen_height=864&browser_language=zh-CN&browser_platform=Win32&browser_name=Chrome&browser_version=104.0.0.0&browser_online=true&engine_name=Blink&engine_version=104.0.0.0&os_name=Windows&os_version=10&cpu_core_num=8&device_memory=8&platform=PC&downlink=10&effective_type=4g&round_trip_time=50&webid=7108568165185701410&msToken=0S05NQssys7tkMSnHqonQ9BSu94CRzvLlQmg5WSFz6uaNN56uOBhetDJM9mLxG2-Gf_Hx_w7WdRQ3WtR4awJAdmIKUt_AZgcIVrRSlMXHc4RyBX9pTcX&X-Bogus=DFSzsnVORLsANVghSBBu/F9WX7jL&_signature=_02B4Z6wo00001CxXOLwAAIDArFXC.YxS2RgsXzwAAGgaD1dM9QA9U8BfRDUdUfPp4C56zM6Lr3gTqu4e7Sa5cW-uEFtlddtihDrQKD1krF3YcfU28JnTZxFgoM5-byxc1tGZuKtl7Pv0-UT029"

headers = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "accept-encoding": "gzip, deflate",
    "accept-language": "zh-CN,zh;q=0.9",
    "cache-control": "no-cache",
    "cookie": "msToken=pgryJyaD6KxF1thiZPNCLMUOGoXuSXwtTEEQfhcOqOQRd67i4oWP7EjWsFD9HqTVewHLaUDfMfqR0GDyRpfXRbBy_bhB3yro4CgXgw9sr0YsEtmkgBVM",
    "pragma": "no-cache",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36",
}

res = requests.get(url=url, headers=headers)
print(res.status_code)
print(res.headers)
print(res.text)
